#-*- coding: utf8 -*-
import json
import requests
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
from datetime import datetime as dt
import os
import logging
logger = logging.getLogger("data_log")

#URL_TPL = "https://api.waqi.info/api/widget/@{}/widget.v1.json"
URL_TPL = "https://api.waqi.info/feed/geo:{};{}/?token=0ebaba336d284b5491301288e33b09a25a7d7fd6"


CITY_DT_MARK = {}


class SiteData(object):

    def __init__(self, data_str, city=""):
        self.city = city
        self.name = ""
        self.lat = 0  #纬度
        self.lon = 0  #经度
        self.date = ""
        self.hour = 0  #小时
        self.ori_str = data_str

        self.aqi = 0
        self.keys = ["pm25", "pm10", "o3", "no2", "so2", "co", "t", "d", "p", "h", "w", "wd"]
        self.pp_data = []
        self.__parse_data_str()

    def __parse_data_str(self):
        try:
            data = json.loads(self.ori_str)
        except ValueError:
            return
        if data["status"] == "error":
            return

        m = data["data"]
        t_str = m["time"]["s"]

        d = m["city"]

        #need replace the "," inside the name
        self.name = d["name"]
        self.name = "|".join(self.name.split(","))

        self.lat = d["geo"][0]
        self.lon = d["geo"][1]
        t = dt.strptime(t_str, "%Y-%m-%d %H:%M:%S")
        self.date = t.date()
        self.hour = t.hour

        self.aqi = m["aqi"]
        if "iaqi" in m:
            pp_dict = m["iaqi"]
        else:
            pp_dict = {}
        for key in self.keys:
            if key in pp_dict:
                v = pp_dict[key]["v"]
                if v == "-":
                    v = -999
                self.pp_data.append(v)
            else:
                self.pp_data.append(-999)

    def out(self):
        data_list = [self.city, self.name, str(self.lat), str(self.lon),
                     self.date.strftime("%Y-%m-%d"), str(self.hour), str(self.aqi)]
        pp_data_str = []
        for d in self.pp_data:
            pp_data_str.append(str(d))
        data_list.extend(pp_data_str)
        line = ",".join(data_list)
        logger.info(line)

    def out_ori(self):
        with open("ori.dat", "a") as f:
            f.write(self.ori_str + "\n")

    def __eq__(self, other):
        return self.date == other.date and self.hour == other.hour


class Site(object):

    def __init__(self, name, x, lat, lon, city):
        self.name = name
        self.x = x   #监测点编号
        self.lat = lat
        self.lon = lon
        self.city = city  #所属城市


def get_site_list(city_file_path):
    site_list = []
    with open(city_file_path, "r") as f:
        json_str = f.read()
        ss = json.loads(json_str)
        for s in ss:
            site_id = s["x"]
            site_name = s["city"]
            site_lat = s["lat"]
            site_lon = s["lon"]
            site_city = os.path.basename(city_file_path).split(".")[0]
            site = Site(site_name, site_id, site_lat, site_lon, site_city)
            site_list.append(site)
    return site_list


def get_site_data(site):
    print "{} {} {}".format(site.city, site.name, site.x)
    url = URL_TPL.format(site.lat, site.lon)
    print url
    try:
        ret = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36",
                                          "Host": "api.waqi.info"})
    except requests.ConnectionError:
        return

    if ret.status_code == 200:
        json_str = ret.text
        site_data = SiteData(json_str, site.city)
        if site_data.name == "":
            return
        else:
            return site_data
    else:
        return


def get_city_data(city_file_path):
    """
    获得一个城市所有站点的数据
    某个站点连接失败，重连三次
    """
    site_list = get_site_list(city_file_path)

    # # not update yet?
    # first_site = site_list[0]
    # city = first_site.city
    # print "{}:".format(city)
    # site_data = get_site_data(first_site)
    # if site_data:
    #     if CITY_DT_MARK.has_key(city):
    #         if CITY_DT_MARK[city] == site_data:
    #             print "{} current: {} {}, not update yet".format(city,
    #                                                              site_data.date.strftime("%Y-%m-%d"),
    #                                                              site_data.hour)
    #             return
    #     CITY_DT_MARK[city] = site_data
    # else:
    #     return

    failed_site_list = []
    for site in site_list:
        site_data = get_site_data(site)
        if not site_data:
            failed_site_list.append(site)
        else:
            site_data.out()
            site_data.out_ori()
    for i in range(3):
        tmp = failed_site_list[:]
        failed_site_list = []
        for site in tmp:
            site_data = get_site_data(site)
            if not site_data:
                failed_site_list.append(site)
            else:
                site_data.out()
                site_data.out_ori()
    for site in failed_site_list:
        print "ERROR: {} {} failed".format(site.city, site.name)


if __name__ == "__main__":
    get_city_data(r"city/dezhou.json")

