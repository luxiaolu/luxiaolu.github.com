import sched
import time
import os
import logging
from logging.handlers import TimedRotatingFileHandler
from spyder import get_city_data

CITY_DIR = "city"

logger = logging.getLogger("data_log")
logger.setLevel(logging.INFO)
handler = TimedRotatingFileHandler("air_data.log",
                                   when="midnight")
logger.addHandler(handler)

schedule = sched.scheduler(time.time, time.sleep)


def task(interval):
    city_files = os.listdir(CITY_DIR)
    for city_file in city_files:
        if not city_file.endswith(".json"):
            continue
        city_file_path = os.path.join(CITY_DIR, city_file)
        get_city_data(city_file_path)
    schedule.enter(interval, 0, task, (interval,))


def main(interval=20*60):
    schedule.enter(0, 0, task, (interval,))
    schedule.run()


if __name__ == "__main__":
    main()
