import logging
from logging.handlers import TimedRotatingFileHandler
logger = logging.getLogger("data_log")
logger.setLevel(logging.INFO)
handler = TimedRotatingFileHandler("air_data.log",
                                   when="midninght")
logger.addHandler(handler)